package org.example;

public class Bike extends Vehicles
{
    public Bike(int speed, String prod)
    {
        type = "bike";
        max_speed = speed;
        producer = prod;
    }
}
