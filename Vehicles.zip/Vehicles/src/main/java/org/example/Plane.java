package org.example;

public class Plane extends Vehicles
{
    public Plane(int speed, String prod)
    {
        type = "plane";
        max_speed = speed;
        producer = prod;
    }
}
