package org.example;

public class Vehicles
{
    int max_speed;
    String producer;
    String type;
}
