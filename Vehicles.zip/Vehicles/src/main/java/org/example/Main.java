package org.example;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class Main
{
    final static Logger log = Logger.getLogger(Main.class);
    public static void main(String[] args)
    {
        //cars
        Car bmw = new Car(250,"BMW");
        Car mercedes = new Car(200,"Mercedes");
        //ships
        Ship ship1 = new Ship(100,"Producer1");
        Ship ship2 = new Ship(90,"Producer2");
        //planes
        Plane plane1 = new Plane(280,"Birch_tree");
        Plane plane2 = new Plane(300,"Bermuda Triangle");
        //bikes
        Bike bmx = new Bike(50,"BMX");
        Bike noname_bike = new Bike(30,"Noname");
        //list related
        List<Vehicles> list = new ArrayList<>();
        list.add(bmw);
        list.add(mercedes);
        list.add(ship1);
        list.add(ship2);
        list.add(plane1);
        list.add(plane2);
        list.add(bmx);
        list.add(noname_bike);
        log.debug("ebe");

    }
}