package org.example;

public class Ship extends Vehicles
{
    public Ship(int speed, String prod)
    {
        type = "ship";
        max_speed = speed;
        producer = prod;
    }
}
