package org.example;

public class Car extends Vehicles
{
    public Car(int speed, String prod)
    {
        type = "car";
        max_speed = speed;
        producer = prod;
    }
}
